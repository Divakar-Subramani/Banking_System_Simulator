This File contains a full integration C++ code and also some of the user defined header files that needed to be included.
The zip file also contains many text files some of them are requires pre-hand to work with and some are generated automatically while the code is executing. 
The Project output will be displayed only in the console. This project may be used for other purposes also with using this as a base but inform us prehanded.
